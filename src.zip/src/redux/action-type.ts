export enum ActionType {
    LOGIN, IS_COMPANY, ADD_COMPANIES
}