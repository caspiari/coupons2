export class UserLoginDetails{
    public constructor(
        public username?:string,
        public password?:string,
    ){}

}