export enum UserType{
    CUSTOMER = "CUSTOMER",
    COMPANY = "COMPANY",
    ADMIN = "ADMIN"
}