import { Component } from 'react'
import "./About.css";

export default class About extends Component {
    public render() {
        return (
        <div></div>
        
        );
    }
  }
